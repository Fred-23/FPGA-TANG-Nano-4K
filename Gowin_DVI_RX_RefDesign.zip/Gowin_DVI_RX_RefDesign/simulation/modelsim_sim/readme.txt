Attention, please: 
	1. If use external clock, I_serial_clk must be five times the frequency of I_rgb_clk
    2. If Phase Search Mode choose Auto mode, please select Auto Phase Simulation Acceleration to accelerate simulation


1.Run Command
    method : do tb.do , in the Transcript windows of the Modelsim Tool

2.Files Introduction

    tb.do       : modelsim  do(command) file
    tb_wave.do  : modelsim add signals to wave file

